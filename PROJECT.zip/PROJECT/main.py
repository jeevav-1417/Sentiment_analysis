import streamlit as st
import re
from nltk.tokenize import word_tokenize
from nltk.corpus import stopwords
from nltk.stem import PorterStemmer
import joblib
import numpy as np
import tensorflow as tf

# Load model and TF-IDF vectorizer
model = tf.keras.models.load_model("model.h5")
tf_idf_vector = joblib.load("tfidf.pkl")

# Initialize NLTK objects
stemmer = PorterStemmer()
stop_words = set(stopwords.words('english'))

# Prediction function
def predict_sentiment(review):
    # Clean and preprocess the review
    cleaned_review = re.sub('<.*?>', '', review)
    cleaned_review = re.sub(r'[^\w\s]', '', cleaned_review)
    cleaned_review = cleaned_review.lower()
    tokenized_review = word_tokenize(cleaned_review)
    filtered_review = [word for word in tokenized_review if word not in stop_words]
    stemmed_review = [stemmer.stem(word) for word in filtered_review]
    
    # Join the stemmed words back into a single string
    processed_review = ' '.join(stemmed_review)

    # Transform the processed review using TF-IDF
    tfidf_review = tf_idf_vector.transform([processed_review])

    # Convert sparse matrix to dense array for Keras model
    tfidf_dense = tfidf_review.toarray()

    # Make prediction
    sentiment_prediction = model.predict(tfidf_dense)

    # Interpret the prediction
    if sentiment_prediction[0][0] > 0.5:
        return "Positive"
    else:
        return "Negative"

# Streamlit UI
st.title("Sentiment Analysis Chatbot")

# Add a description
st.write("""
    ### Analyze the sentiment of your reviews:
    Enter a review below, and the model will predict whether it's **Positive** or **Negative**.
""")

# Use columns to structure the layout
col1, col2 = st.columns([3, 1])

# Input area for the review
with col1:
    review_to_predict = st.text_area("Enter your review:")

# Prediction button and output
if st.button("Predict Now!"):
    with st.spinner('Predicting sentiment...'):
        predicted_sentiment = predict_sentiment(review_to_predict)
    
    # Display sentiment with styling
    if predicted_sentiment == "Positive":
        st.success(f"Predicted Sentiment: {predicted_sentiment}")
    else:
        st.error(f"Predicted Sentiment: {predicted_sentiment}")
else:
    st.write("Submit a review to see the sentiment analysis.")

# Optional: Add a horizontal divider
st.divider()


